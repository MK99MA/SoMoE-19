1. Place 0_bg_soccer.bsp EITHER in cstrike/maps OR cstrike/download/maps
2. Go to Steam -> Library
3. Right-click on Counter-Strike: Source -> Properties... -> General
4. In the textbox for "Launch Options" add "+map_background 0_bg_soccer
5. Start CS:S and check if it works...