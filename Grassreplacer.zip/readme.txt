1. Place 0_bg_soccer.bsp EITHER in cstrike/maps OR cstrike/download/maps
2. Choose one of the following methods:
	a. Launch Parameters 
	!! (If you join someone via Steamfriends it will abort connecting and put you into mainmenu)
		Go to Steam -> Library
		Right-click on Counter-Strike: Source -> Properties... -> General
		In the textbox for "Launch Options" add "+map_background 0_bg_soccer" OR "+map_background 0_bg_soccer_light" (without the "")
	b. autoexec.cfg 
	!! (If you join via Steamfriends it WON'T work, only if you start the game first)
		Go to cstrike/cfg
		Open your autoexec.cfg OR create a new one if it doesn't exist
		Add "map_background 0_bg_soccer" OR "map_background 0_bg_soccer_light" to the file (without the "")
	c. Manual usage
	!! (If you don't do this first after joining any map with a soccermap it won't work until you restart CS:S)
		Start CS:S and use "map_background 0_bg_soccer" OR "map_background 0_bg_soccer_light" (without the "")
5. Start CS:S and check if it works...